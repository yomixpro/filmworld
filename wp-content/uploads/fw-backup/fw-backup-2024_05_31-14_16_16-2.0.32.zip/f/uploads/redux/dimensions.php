<?php
   class Redux_Customizer_Control_dimensions extends Redux_Customizer_Control {
     public $type = "redux-dimensions";
   }
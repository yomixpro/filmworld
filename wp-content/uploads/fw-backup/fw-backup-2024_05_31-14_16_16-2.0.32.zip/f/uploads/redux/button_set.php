<?php
   class Redux_Customizer_Control_button_set extends Redux_Customizer_Control {
     public $type = "redux-button_set";
   }
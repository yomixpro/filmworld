<?php
   class Redux_Customizer_Control_ace_editor extends Redux_Customizer_Control {
     public $type = "redux-ace_editor";
   }